
# coding: utf-8

# In[2]:


import numpy as np
import pandas as pd
import matplotlib as mpl
import matplotlib.pyplot as plt
from scipy.io import arff
from sklearn.model_selection import train_test_split
from sklearn import tree
from sklearn import metrics
params = {'legend.fontsize': 'x-small',
         'axes.labelsize': 'x-small',
         'axes.titlesize':'x-small',
         'xtick.labelsize':'x-small',
         'ytick.labelsize':'x-small'}
plt.rcParams.update(params)


# In[11]:


#dataset = arff.loadarff('bank-additional-full_preprocessed.csv.arff')
datacsv_add=pd.read_csv("bank-additional-full.csv")
df = pd.DataFrame(datacsv_add)
datacsv_full=pd.read_csv("bank-full.csv")
#datasets where "unknown" is replaced with null
data1=pd.read_csv("bank-additional-full_null.csv")
data2=pd.read_csv("bank-full_null.csv")
df1=pd.DataFrame(data1)
df2=pd.DataFrame(data2)
len1=len(df1.index)
len2=len(df2.index)
print(len1)
print(len2)



# In[12]:


#display percentage of missing values of bank_additional
df_train=pd.DataFrame(data1)
#total_missing=df_train.isnull().sum(axis=0).sum()
#print(total_missing)
missing_df = df_train.isnull().sum(axis=0).reset_index()
missing_df.columns = ['column_name', 'missing_count']
missing_df = missing_df.loc[missing_df['missing_count']>0]
missing_df = missing_df.sort_values(by='missing_count')
print(missing_df)
missing_df['missing_count']= missing_df['missing_count'] * 100 / len1
ind = np.arange(missing_df.shape[0])
width = 0.8
fig, ax = plt.subplots(figsize=(8,8))
rects = ax.barh(ind, missing_df.missing_count.values, color='blue')
ax.set_yticks(ind)
ax.set_yticklabels(missing_df.column_name.values, rotation='horizontal',fontsize=16)
ax.set_xlabel("% of unknown values")
ax.set_title("Bank-additional-full")
plt.show()

#display percentage of missing values of bank_full
df_train=pd.DataFrame(data2)
#total_missing=df_train.isnull().sum(axis=0).sum()
#print(total_missing)
missing_df = df_train.isnull().sum(axis=0).reset_index()
missing_df.columns = ['column_name', 'missing_count']
missing_df = missing_df.loc[missing_df['missing_count']>0]
missing_df = missing_df.sort_values(by='missing_count')
print(missing_df)
missing_df['missing_count']= missing_df['missing_count'] * 100 / len2
ind = np.arange(missing_df.shape[0])
width = 0.8
fig, ax = plt.subplots(figsize=(8,8))
rects = ax.barh(ind, missing_df.missing_count.values, color='blue')
ax.set_yticks(ind)
ax.set_yticklabels(missing_df.column_name.values, rotation='horizontal',fontsize=16)
ax.set_xlabel("% of unknown values")
ax.set_title("Bank-full")
plt.show()


# In[13]:


import seaborn as sns
sns.set(style="whitegrid", color_codes=True)
np.random.seed(sum(map(ord, "categorical")))

#scatter plot: input attributes x and y
sns.stripplot(x="education", y="age", data=datacsv_add);

#chi-squared test for bank_additional-full:modify the attributes as needed 
table=pd.crosstab(datacsv_add['default'],datacsv_add['month'])
from scipy.stats import chi2_contingency
chi2, p, dof, expected = chi2_contingency(table.values)
#print(table)
print(chi2)
print(p)


# In[14]:


#corr = df.corr()
#fig, ax = plt.subplots(figsize=(20, 20))
#ax.matshow(corr)
#plt.xticks(range(len(corr.columns)), corr.columns);
#plt.yticks(range(len(corr.columns)), corr.columns);


# In[15]:


#correlation matrix of numeric attributes in bank_additional-full
import seaborn as sns
f1, ax1 = plt.subplots(figsize=(20, 20))
corr = df.corr()
sns.heatmap(corr, mask=np.zeros_like(corr, dtype=np.bool), cmap=sns.diverging_palette(220, 10, as_cmap=True),
            square=True, ax=ax1)


# In[97]:


#correlation matrix of numeric attributes in bank-full
df2 = pd.DataFrame(datacsv_full)
#import seaborn as sns
f2, ax2 = plt.subplots(figsize=(16, 16))
corr2 = df2.corr()
sns.heatmap(corr2, mask=np.zeros_like(corr2, dtype=np.bool), cmap=sns.diverging_palette(220, 10, as_cmap=True),
            square=True, ax=ax2)


# In[16]:


#chi-squared test for bank-full:modify the attributes as needed 
table=pd.crosstab(datacsv_full['month'],datacsv_full['poutcome'])
from scipy.stats import chi2_contingency
chi2, p, dof, expected = chi2_contingency(table.values)
#print(table)
print(chi2)
print(p)


# In[72]:


#preprocess data 
#One-Hot Enconding
bank_preprocess = pd.get_dummies(data=df1, columns = ['job', 'marital', 'education', 'default','housing','loan','contact','poutcome'],                     prefix = ['job', 'marital', 'education', 'default','housing','loan','contact','poutcome'])
#Integer Encoding
int_encode= {"month":{"jan": 1, "feb": 2, "mar": 3, "apr": 4, "may": 5, "jun": 6, "jul":7, "aug": 8, "sep": 9,
             "oct": 10, "nov": 11, "dec": 12}, "day_of_week": {"mon": 1, "tue": 2, "wed": 3, "thu": 4,  "fri": 5 }}
bank_preprocess.replace(int_encode, inplace=True)
bank_preprocess.head()


# In[77]:


#Correlation matrix after data preprocessing
correlation = bank_preprocess.corr()
correlation


# In[80]:


#plot correlation matrix after data preprocessing
plt.figure(figsize = (10,10))
cmap = sns.diverging_palette(200, 10, as_cmap=True)
sns.heatmap(correlation, xticklabels=correlation.columns.values, yticklabels=correlation.columns.values, cmap=cmap, vmax=.3, center=0, square=True, linewidths=.3, cbar_kws={"shrink": .82})
plt.title('Heatmap of Correlation Matrix')

