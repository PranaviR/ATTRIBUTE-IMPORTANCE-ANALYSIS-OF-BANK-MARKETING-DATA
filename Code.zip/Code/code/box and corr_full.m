%read data
M = csvread('bank-full-numeric.csv', 0, 0, [0 0 45210 6])
%standardize
%calculate mean 
M_mean = mean(M)
[row_count column_count]= size(M)
for column = 1:column_count
 for row = 1:row_count
   M_centred(row, column) = M(row, column) - M_mean(column);
 end
end
%calculate variance
M_std_dev = std(M_centred)
for column = 1:column_count
 for row = 1:row_count
   M_centred_scaled(row, column) = M_centred(row,column)/M_std_dev(column);
 end
end
X = M_centred_scaled
%boxplot(X)
figure(1)
boxplot(X,'Labels',{'Age','Balance','Day','Duration','Campaign','Pdays','Previous'})
%covariance matrix = correlation matrix because unit variance
corr_matrix = cov(X)
%correlation matrix plot
figure(2)
set(gca,'FontSize',16);
corrplot(X,'varNames',{'Age','Balance','Day','Duration','Campaign','Pdays','Previous'})

